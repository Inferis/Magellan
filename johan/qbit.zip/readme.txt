Qbit Version 1.0.0.10

Qbit is an image viewer that loads and saves it's own imge format as well 
as loading various Sun Raster File, Targa and Bitmap files.  

Qbit does NOT render or save transparencies or alpha information.  Typically 
Qbit will refuse to load the file at all.  A single alpha bit in 16 bit files 
may end up encoded in a Qbit file, but will not be read by the viewer.

Commands
F1	Help
F2	Properties
F3	Open...
F4	Save...
F5	Reload
Alt-F5	Run
F6\F7	Zoom In\Out
F11\F12	Rotate CW\CCW
Home	First
End	Last
Baclspace\PgUp	Previous
Alt-Right Arrow\PgDn	Next
Delete	Remove From History
Alt-F7	Test File Size
Esc	Quit\Stop

Usage
Qbit.exe (QBIT | BITMAP) [PROGRESS] file [file file...]

QBIT	convert <file(s)> to a compressed Qbit file
BITMAP	convert <file(s)> to a Windows Bitmap file
PROGRESS	display a progress window

Registry key
HKEY_CURRENT_USER\\Software\\Qbit

Home page
www3.sympatico.ca/doug_houghton/qbit.html

Email
doug_houghton@sympatico.ca


THIS SOFTWARE IS FREE AND PROVIDED AS IS WITH NO GAURANTEE OF ANY KIND FOR 
IT'S  QUALITY, ACCURACY OR RELIABILITY.  THE AUTHOR IS IN NO WAY LIABLE FOR 
ANY DAMAGES RESULTING FROM OR RELATED TO THE USE OF THIS SOFTWARE. USE AT 
OWN RISK.

File formats are subject to change without warning.